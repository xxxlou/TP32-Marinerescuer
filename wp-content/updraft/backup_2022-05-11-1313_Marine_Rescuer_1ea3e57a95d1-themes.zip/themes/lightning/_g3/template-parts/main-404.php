<?php
/**
 * 404 main template
 *
 * @package vektor-inc/lightning
 */
?>

<div class="main-section-no-posts">
	<p>
		<?php echo __( 'The page you are looking for cannot be found.', 'lightning' ); ?>
	</p>
</div>
