<?php
/* This file is used to fallback when post type template file was don't exist. */
get_template_part( 'template-parts/post/loop-layout', 'media' );
